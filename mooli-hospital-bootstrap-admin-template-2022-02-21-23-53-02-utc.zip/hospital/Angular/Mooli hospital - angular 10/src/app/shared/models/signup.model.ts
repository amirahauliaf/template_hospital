export interface SignupModel {
  firstname: string;
  lastname: string;
  email: string;
  contactnumber: string;
  gender: string;
  dob: string;
  password: string;
}