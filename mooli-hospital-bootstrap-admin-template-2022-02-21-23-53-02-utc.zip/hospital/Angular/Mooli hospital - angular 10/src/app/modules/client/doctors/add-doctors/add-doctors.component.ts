import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-doctors',
  templateUrl: './add-doctors.component.html',
  styleUrls: ['./add-doctors.component.scss']
})
export class AddDoctorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
