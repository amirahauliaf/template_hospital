import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-invoices',
  templateUrl: './patient-invoices.component.html',
  styleUrls: ['./patient-invoices.component.scss']
})
export class PatientInvoicesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
