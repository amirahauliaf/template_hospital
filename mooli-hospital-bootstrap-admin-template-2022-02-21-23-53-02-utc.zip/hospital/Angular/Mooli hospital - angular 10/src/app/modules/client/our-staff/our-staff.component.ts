import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-staff',
  templateUrl: './our-staff.component.html',
  styleUrls: ['./our-staff.component.scss']
})
export class OurStaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
