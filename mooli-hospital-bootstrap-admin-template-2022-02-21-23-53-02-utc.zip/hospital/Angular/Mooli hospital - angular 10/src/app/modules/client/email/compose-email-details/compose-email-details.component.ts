import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compose-email-details',
  templateUrl: './compose-email-details.component.html',
  styleUrls: ['./compose-email-details.component.scss']
})
export class ComposeEmailDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
