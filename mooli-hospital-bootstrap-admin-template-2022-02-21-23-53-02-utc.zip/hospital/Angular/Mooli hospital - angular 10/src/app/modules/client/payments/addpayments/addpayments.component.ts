import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addpayments',
  templateUrl: './addpayments.component.html',
  styleUrls: ['./addpayments.component.scss']
})
export class AddpaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
