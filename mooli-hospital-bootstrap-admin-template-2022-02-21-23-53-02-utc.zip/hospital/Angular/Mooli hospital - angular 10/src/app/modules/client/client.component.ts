import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-client',
    templateUrl: './client.component.html'
})
export class ClientComponent implements OnInit {

    constructor() { }

    ngOnInit(): void {
    }
    closeMenu() {
        const body = document.getElementsByTagName('body')[0].classList.remove("offcanvas-active");
    }
}
