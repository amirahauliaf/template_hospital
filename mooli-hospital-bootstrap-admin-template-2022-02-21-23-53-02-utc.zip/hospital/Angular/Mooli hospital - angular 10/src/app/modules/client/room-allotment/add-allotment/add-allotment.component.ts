import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-allotment',
  templateUrl: './add-allotment.component.html',
  styleUrls: ['./add-allotment.component.scss']
})
export class AddAllotmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
