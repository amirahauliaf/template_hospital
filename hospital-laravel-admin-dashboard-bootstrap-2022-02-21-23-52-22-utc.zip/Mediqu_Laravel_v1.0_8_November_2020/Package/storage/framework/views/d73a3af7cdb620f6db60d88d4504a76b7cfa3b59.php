





<?php $__env->startSection('content'); ?>
<div class="col-md-5">
  <div class="form-input-content text-center error-page">
      <h1 class="error-text font-weight-bold">500</h1>
      <h4><i class="fa fa-times-circle text-danger"></i> Internal Server Error</h4>
      <p>You do not have permission to view this resource</p> 
      <div>
          <a class="btn btn-primary"  href="<?php echo url('/index');; ?>">Back to Home</a>
      </div>	
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.fullwidth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mediqu\resources\views/page/error500.blade.php ENDPATH**/ ?>