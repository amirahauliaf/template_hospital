





<?php $__env->startSection('content'); ?>
	<div class="col-md-6">
		<div class="authincation-content">
			<div class="row no-gutters">
				<div class="col-xl-12">
					<div class="auth-form">
						<h4 class="text-center mb-4">Sign up your account</h4>
						<form action="<?php echo url('/index');; ?>">
							<div class="form-group">
								<label><strong>Username</strong></label>
								<input type="text" class="form-control" placeholder="username">
							</div>
							<div class="form-group">
								<label><strong>Email</strong></label>
								<input type="email" class="form-control" placeholder="hello@example.com">
							</div>
							<div class="form-group">
								<label><strong>Password</strong></label>
								<input type="password" class="form-control" value="Password">
							</div>
							<div class="text-center mt-4">
								<button type="submit" class="btn btn-primary btn-block">Sign me up</button>
							</div>
						</form>
						<div class="new-account mt-3">
							<p>Already have an account? <a class="text-primary" href="<?php echo url('/page-login');; ?>">Sign in</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.fullwidth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mediqu\resources\views/page/register.blade.php ENDPATH**/ ?>