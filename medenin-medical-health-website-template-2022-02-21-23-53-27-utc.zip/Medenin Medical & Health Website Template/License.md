Hello,

Thank you for purchasing this template. 

Read about licensing details here: http://themeforest.net/licenses

Thanks a lot,

~Surjith