Latest Version : v1.0 (28 Aug, 2020)

See "Changelog" Section in the documentation (Help Docs) for detailed changelog.